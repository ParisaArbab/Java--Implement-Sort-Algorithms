Following the steps below to compile the source codes and execute the algorithms in the project directory:

Step 1: Navigate to project directory,

Step 2: To build each [AlgorithmName].java source file run the following command:
		javac [AlgorithmName].java
		After running the above command, you may verify the existence of a [AlgorithmName].class file in the directory by using an ls command

Step 3: To run each algorithm program after you succesfully built it's java program, run the following command:
		java [AlgorithmName]

Step 4: The Program will run and ask you "Please enter the dataset directory absolute path", so enter the full path of the dataset directory and
	hit enter. The program should output 16	lines of output in the same order of data types	as described in the assignment document.


IMPORTANT!!!!
	- Source codes are developed by Java 8,
	- Execution times are in nanoseconds,
	- For each sorting algorithm there is a java source file named [AlgorithmName].java in the project directory,
        - All source files are named in PascalCase Manner(InsertionSort.java, MergeSort.java, ...), 
	- In addition to 5 algorithm java class files there is another two java class files (including Sorter.java & Util.java) which 
	  are used as base and utility classes respectively.
	

